"""
Vector Memory Store: 基于向量数据库的记忆系统
存储历史审查模式，支持相似案例检索
"""
from typing import Dict, List, Any, Optional
import json
import hashlib
from datetime import datetime

class VectorMemoryStore:
    """
    向量记忆系统

    核心能力：
    1. 存储审查模式：将每次审查结果向量化存储
    2. 相似检索：基于向量相似度找到历史相似案例
    3. 模式学习：识别高频问题类型，优化 Agent 策略

    实际部署使用 ChromaDB / Milvus / Pinecone
    此处展示接口和内存实现
    """

    def __init__(self, embedding_model: Optional[Any] = None):
        self.embedding_model = embedding_model
        self.memory: Dict[str, Dict] = {}  # 内存存储（实际应使用向量数据库）
        self.patterns: Dict[str, int] = {}  # 模式频率统计

    async def store(self, document: Dict[str, Any]) -> str:
        """
        存储审查记录到记忆系统

        Args:
            document: 包含 id, content, metadata 的文档

        Returns:
            存储的文档 ID
        """
        doc_id = document.get("id", self._generate_id(document))

        # 生成向量（简化版：使用哈希特征）
        vector = self._generate_vector(document["content"])

        self.memory[doc_id] = {
            "id": doc_id,
            "vector": vector,
            "content": document["content"],
            "metadata": document.get("metadata", {}),
            "timestamp": datetime.now().isoformat()
        }

        # 更新模式统计
        self._update_patterns(document)

        return doc_id

    async def search(self, query: str, top_k: int = 5) -> List[Dict[str, Any]]:
        """
        相似案例检索

        Args:
            query: 查询文本
            top_k: 返回结果数量

        Returns:
            相似度排序的结果列表
        """
        query_vector = self._generate_vector(query)

        # 计算余弦相似度
        similarities = []
        for doc_id, doc in self.memory.items():
            sim = self._cosine_similarity(query_vector, doc["vector"])
            similarities.append((doc_id, sim, doc))

        # 排序并返回 top_k
        similarities.sort(key=lambda x: x[1], reverse=True)

        return [
            {
                "id": doc_id,
                "similarity": round(sim, 4),
                "content": doc["content"],
                "metadata": doc["metadata"],
                "timestamp": doc["timestamp"]
            }
            for doc_id, sim, doc in similarities[:top_k]
        ]

    async def get_patterns(self, min_frequency: int = 3) -> List[Dict[str, Any]]:
        """
        获取高频审查模式

        Args:
            min_frequency: 最小出现频率

        Returns:
            高频模式列表
        """
        return [
            {"pattern": pattern, "frequency": freq}
            for pattern, freq in sorted(self.patterns.items(), key=lambda x: -x[1])
            if freq >= min_frequency
        ]

    async def get_stats(self) -> Dict[str, Any]:
        """获取记忆系统统计"""
        return {
            "total_memories": len(self.memory),
            "unique_patterns": len(self.patterns),
            "top_patterns": await self.get_patterns(min_frequency=1),
            "storage_size_kb": sum(len(json.dumps(d)) for d in self.memory.values()) / 1024
        }

    def _generate_id(self, document: Dict) -> str:
        """生成文档 ID"""
        content = document.get("content", "")
        return hashlib.md5(content.encode()).hexdigest()[:12]

    def _generate_vector(self, text: str, dim: int = 128) -> List[float]:
        """
        生成文本向量（简化版）

        实际部署应使用：
        - OpenAI text-embedding-ada-002
        - 本地 Sentence-BERT
        - 自定义编码器
        """
        # 基于字符频率的简单哈希向量
        vector = [0.0] * dim
        for i, char in enumerate(text):
            idx = ord(char) % dim
            vector[idx] += 1.0

        # 归一化
        magnitude = sum(v**2 for v in vector) ** 0.5
        if magnitude > 0:
            vector = [v / magnitude for v in vector]

        return vector

    def _cosine_similarity(self, v1: List[float], v2: List[float]) -> float:
        """计算余弦相似度"""
        dot = sum(a * b for a, b in zip(v1, v2))
        mag1 = sum(a**2 for a in v1) ** 0.5
        mag2 = sum(b**2 for b in v2) ** 0.5

        if mag1 == 0 or mag2 == 0:
            return 0.0
        return dot / (mag1 * mag2)

    def _update_patterns(self, document: Dict) -> None:
        """更新模式频率统计"""
        metadata = document.get("metadata", {})

        # 基于风险等级统计
        risk = metadata.get("risk_level", "unknown")
        self.patterns[f"risk_{risk}"] = self.patterns.get(f"risk_{risk}", 0) + 1

        # 基于问题数量统计
        issues = metadata.get("issues_count", 0)
        if issues > 10:
            self.patterns["high_issue_count"] = self.patterns.get("high_issue_count", 0) + 1
        elif issues > 5:
            self.patterns["medium_issue_count"] = self.patterns.get("medium_issue_count", 0) + 1
        else:
            self.patterns["low_issue_count"] = self.patterns.get("low_issue_count", 0) + 1
