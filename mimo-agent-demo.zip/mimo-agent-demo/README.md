# MiMO Agent Demo — 智能代码审查与自动化重构系统

## 项目概述

本项目构建了一个基于多 Agent 协作架构的智能代码审查系统，核心解决**大型代码库中技术债累积、人工 Code Review 效率低、重构风险不可控**三大痛点。

### 核心痛点
1. **技术债隐形化**：存量代码中的坏味道（God Class、Long Method、Circular Dependency）难以被系统性发现
2. **Review 瓶颈**：20 人后端团队日均产生 50+ PR，人工 Review 覆盖率不足 40%，关键风险常被遗漏
3. **重构高风险**：缺乏自动化验证闭环，重构后引入回归 Bug 的概率高达 15%

### 架构亮点
- **4 个专业 Agent 协作**：分析 → 生成 → 重构 → 验证
- **长链推理（Chain-of-Thought）**：复杂场景下通过 5-7 步推理链决策最优重构策略
- **记忆系统**：基于向量数据库存储历史审查模式，实现越用越准的个性化建议
- **闭环验证**：自动运行单元测试 + 静态分析 + 语义比对，确保重构零回归

## 技术栈
- Python 3.10+
- FastAPI + asyncio
- LangChain / 自定义 CoT 引擎
- Tree-sitter（代码解析）
- ChromaDB（向量记忆）

## 快速开始

```bash
pip install -r requirements.txt
python examples/demo.py
```

## 核心逻辑流

```
用户提交 PR
    ↓
[Orchestrator] 任务分解
    ↓
[CodeAnalyzer] 静态扫描 + AST 分析 → 提取坏味道列表
    ↓
[ChainOfThought] 长链推理：评估风险等级 → 选择重构策略 → 预测影响面
    ↓
[RefactorAgent] 执行代码重构（基于规则 + LLM 生成）
    ↓
[TestGenerator] 为变更代码自动生成缺失的单元测试
    ↓
[ValidatorAgent] 运行测试 + 静态检查 + 语义 Diff 比对
    ↓
[Orchestrator] 聚合结果 → 生成 Review Report + 自动提交 PR Comment
    ↓
记忆系统：存储本次审查模式到向量库
```

## Agent 详解

### 1. CodeAnalyzer Agent
- 使用 Tree-sitter 解析 AST
- 检测 12 种代码坏味道（基于《重构》模式）
- 输出结构化风险报告

### 2. ChainOfThought Engine
- 5 步推理链：识别问题 → 分析根因 → 评估影响 → 选择策略 → 生成方案
- 支持自我纠错（Self-Correction）：当验证失败时回溯推理路径

### 3. RefactorAgent
- 双模式：安全重构（Rename/Extract）由规则引擎执行；复杂重构由 LLM 生成
- 所有变更生成统一 Diff 格式

### 4. TestGenerator Agent
- 基于变更代码自动生成 pytest 用例
- 覆盖分支检测：确保新代码路径 100% 覆盖

### 5. ValidatorAgent
- 三级验证：单元测试通过 → 静态分析无新增警告 → 语义等价性验证
- 任一级别失败则阻断流程并回滚

## 成果数据（示例）

> "该系统已在我司 20 人后端团队落地运行 3 个月，接入 5 个核心服务仓库，日均处理 PR 45 个，自动发现高危技术债 120+ 处，生成并通过验证的重构 PR 89 个，代码规范评估效率提升 80%，重构引入的回归 Bug 从 15% 降至 2% 以下，每日消耗 Token 约 300 万。"

## 许可证
MIT
