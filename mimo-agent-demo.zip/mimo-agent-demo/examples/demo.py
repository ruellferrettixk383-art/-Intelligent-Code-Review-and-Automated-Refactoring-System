"""
MiMO Agent Demo — 完整演示脚本
展示多 Agent 协作处理 PR 审查的全流程
"""
import asyncio
import sys
from pathlib import Path

# 添加项目根目录到路径
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.orchestrator import Orchestrator
from agents.code_analyzer import CodeAnalyzer
from agents.chain_of_thought import ChainOfThought
from agents.refactor_agent import RefactorAgent
from agents.test_generator import TestGenerator
from agents.validator_agent import ValidatorAgent
from memory.vector_store import VectorMemoryStore

# 模拟有问题的代码（God Class + Long Method + 循环导入风险）
SAMPLE_BAD_CODE = """
class OrderManager:
    def __init__(self):
        self.orders = []
        self.customers = []
        self.payments = []
        self.shipments = []
        self.notifications = []

    def process_order(self, order_data, customer_id, payment_info, shipping_address, notification_prefs, discount_code, tax_rate, currency):
        # 验证订单
        if order_data:
            if customer_id:
                if payment_info:
                    if shipping_address:
                        if notification_prefs:
                            # 处理支付
                            payment_result = self._process_payment(payment_info, discount_code, tax_rate, currency)
                            if payment_result:
                                # 创建订单
                                order = {
                                    'id': len(self.orders) + 1,
                                    'data': order_data,
                                    'customer': customer_id,
                                    'payment': payment_result,
                                    'shipping': shipping_address,
                                    'notifications': notification_prefs
                                }
                                self.orders.append(order)
                                # 发送通知
                                self._send_notification(customer_id, notification_prefs, "Order created")
                                # 更新库存
                                self._update_inventory(order_data)
                                # 记录日志
                                self._log_order(order)
                                return order
                            else:
                                raise Exception("Payment failed")
                        else:
                            raise Exception("No notification preferences")
                    else:
                        raise Exception("No shipping address")
                else:
                    raise Exception("No payment info")
            else:
                raise Exception("No customer ID")
        else:
            raise Exception("No order data")

    def _process_payment(self, info, code, rate, currency):
        # 复杂支付逻辑
        amount = info.get('amount', 0) * (1 + rate)
        if code == 'SAVE20':
            amount *= 0.8
        return {'amount': amount, 'currency': currency}

    def _send_notification(self, customer_id, prefs, message):
        if prefs.get('email'):
            print(f"Email to {customer_id}: {message}")
        if prefs.get('sms'):
            print(f"SMS to {customer_id}: {message}")

    def _update_inventory(self, order_data):
        for item in order_data.get('items', []):
            print(f"Reducing inventory for {item['id']}")

    def _log_order(self, order):
        with open('orders.log', 'a') as f:
            f.write(str(order) + '\n')

    def get_order(self, order_id):
        for order in self.orders:
            if order['id'] == order_id:
                return order
        return None

    def cancel_order(self, order_id, reason, refund_method, notify_customer, update_inventory, log_action):
        order = self.get_order(order_id)
        if order:
            self.orders.remove(order)
            if refund_method:
                self._process_refund(order, refund_method)
            if notify_customer:
                self._send_notification(order['customer'], order['notifications'], f"Order cancelled: {reason}")
            if update_inventory:
                self._update_inventory(order['data'])
            if log_action:
                self._log_order({'action': 'cancel', 'order_id': order_id, 'reason': reason})
            return True
        return False

    def _process_refund(self, order, method):
        print(f"Processing refund via {method} for order {order['id']}")

    def generate_report(self, start_date, end_date, format_type, include_customers, include_payments, include_shipments, group_by):
        # 生成报告
        filtered = [o for o in self.orders if start_date <= o['data'].get('date', '') <= end_date]
        report = {'orders': filtered, 'format': format_type}
        if include_customers:
            report['customers'] = self.customers
        if include_payments:
            report['payments'] = self.payments
        if include_shipments:
            report['shipments'] = self.shipments
        if group_by:
            report['grouped'] = {}
        return report

    def export_data(self, format, destination, compression, encryption, callback):
        # 导出数据
        data = {'orders': self.orders, 'customers': self.customers}
        if compression:
            data['compressed'] = True
        if encryption:
            data['encrypted'] = True
        if callback:
            callback(data)
        return data

    def import_data(self, source, format, validate, transform, merge_strategy):
        # 导入数据
        pass

    def backup(self, destination, frequency, retention, compression):
        # 备份
        pass

    def restore(self, source, validate, selective):
        # 恢复
        pass

    def migrate_data(self, old_format, new_format, mapping, validation_rules):
        # 迁移
        pass

    def sync_with_external(self, api_endpoint, auth_token, sync_mode, conflict_resolution):
        # 同步
        pass
"""

# 循环导入风险示例
SAMPLE_CIRCULAR_IMPORT = """
# file_a.py
from file_b import helper_b

def function_a():
    return helper_b()

# file_b.py  
from file_a import function_a

def helper_b():
    return function_a()
"""

async def main():
    print("=" * 70)
    print("🚀 MiMO Agent Demo — 智能代码审查与自动化重构系统")
    print("=" * 70)

    # 初始化记忆系统
    memory = VectorMemoryStore()

    # 初始化所有 Agent
    agents = {
        "CodeAnalyzer": CodeAnalyzer(),
        "ChainOfThought": ChainOfThought(),
        "RefactorAgent": RefactorAgent(),
        "TestGenerator": TestGenerator(),
        "ValidatorAgent": ValidatorAgent()
    }

    # 初始化编排器
    orchestrator = Orchestrator(agents, memory)

    # 构建模拟 PR 数据
    pr_data = {
        "id": "PR-2024-001",
        "repo": "order-service",
        "branch": "feature/refactor-order-manager",
        "author": "developer@company.com",
        "diff_files": [
            {
                "path": "src/order_manager.py",
                "content": SAMPLE_BAD_CODE
            },
            {
                "path": "src/file_a.py",
                "content": "from file_b import helper_b\ndef function_a():\n    return helper_b()"
            },
            {
                "path": "src/file_b.py",
                "content": "from file_a import function_a\ndef helper_b():\n    return function_a()"
            }
        ]
    }

    print("\n📋 PR 信息:")
    print(f"   ID: {pr_data['id']}")
    print(f"   仓库: {pr_data['repo']}")
    print(f"   分支: {pr_data['branch']}")
    print(f"   文件数: {len(pr_data['diff_files'])}")

    print("\n" + "=" * 70)
    print("🔍 Phase 1: CodeAnalyzer — 静态代码分析")
    print("=" * 70)

    # 执行完整流程
    result = await orchestrator.process_pr(pr_data)

    # 展示分析结果
    analysis = result["detailed_results"]["analysis"]
    print(f"\n📊 分析摘要:")
    print(f"   发现问题: {analysis['summary']['total_issues']} 个")
    print(f"   风险评分: {analysis['risk_score']}/1.0")
    print(f"   严重级别分布:")
    for sev, count in analysis['summary']['severity_distribution'].items():
        if count > 0:
            print(f"      - {sev}: {count}")

    print(f"\n🔍 问题详情 (Top 5):")
    for i, smell in enumerate(analysis['smells'][:5], 1):
        print(f"   {i}. [{smell['severity'].upper()}] {smell['type']}")
        print(f"      📍 {smell['file']}:{smell['line']}")
        print(f"      📝 {smell['description']}")
        print(f"      💡 {smell['suggestion']}")

    print("\n" + "=" * 70)
    print("🧠 Phase 2: ChainOfThought — 长链推理")
    print("=" * 70)

    reasoning = result["reasoning_chain"]
    print(f"\n🧩 推理链 ({len(reasoning)} 步):")
    for i, step in enumerate(reasoning, 1):
        emoji = ["🔍", "🌳", "📊", "🎯", "📋", "🔄"][i-1] if i <= 6 else "➡️"
        print(f"\n   Step {i} {emoji} [{step['step']}]")
        print(f"   Confidence: {step['confidence']:.2f}")
        print(f"   Thought: {step['thought'][:120]}...")

    print(f"\n📈 最终决策:")
    print(f"   风险等级: {result['summary']['risk_level']}")
    print(f"   重构策略: {result['detailed_results']['refactor'].get('changes_applied', 0)} 项变更")

    print("\n" + "=" * 70)
    print("🔧 Phase 3: RefactorAgent — 自动化重构")
    print("=" * 70)

    refactor = result["detailed_results"]["refactor"]
    print(f"\n📝 变更列表:")
    for i, change in enumerate(refactor.get("changes", [])[:3], 1):
        print(f"\n   {i}. [{change['safety'].upper()}] {change['type']}")
        print(f"      📍 {change['file']}:{change['lines']}")
        print(f"      📝 {change['description']}")

    print(f"\n📊 安全统计:")
    safety = refactor.get("safety_summary", {})
    for level, count in safety.items():
        if count > 0:
            print(f"      - {level}: {count}")

    print("\n" + "=" * 70)
    print("🧪 Phase 4: TestGenerator — 测试生成")
    print("=" * 70)

    tests = result["detailed_results"]["tests"]
    print(f"\n📋 生成测试: {tests['tests_count']} 个")
    print(f"   覆盖率估算: {tests.get('coverage_estimate', {})}")

    if tests.get("test_cases"):
        print(f"\n🧪 测试用例示例:")
        for i, case in enumerate(tests["test_cases"][:3], 1):
            print(f"   {i}. {case['name']} ({case['type']})")
            print(f"      🎯 目标: {case['target']}")
            print(f"      📊 覆盖: {case['coverage']}")

    print("\n" + "=" * 70)
    print("✅ Phase 5: ValidatorAgent — 三级验证")
    print("=" * 70)

    validation = result["detailed_results"]["validation"]
    print(f"\n📊 验证结果:")
    print(f"   通过状态: {'✅ PASSED' if validation.get('passed') else '❌ FAILED'}")

    if validation.get("checks"):
        for check in validation["checks"]:
            emoji = "✅" if check["result"] == "passed" else "⚠️" if check["result"] == "warning" else "❌"
            print(f"   {emoji} [{check['level'].upper()}] {check['result'].upper()}: {check['message']}")

    if validation.get("summary"):
        summary = validation["summary"]
        print(f"\n📈 验证摘要:")
        print(f"      测试通过: {summary.get('tests_passed', 0)}/{summary.get('tests_total', 0)}")
        print(f"      静态警告: {summary.get('static_warnings', 0)}")
        print(f"      语义相似度: {summary.get('semantic_score', 0):.2f}")

    print("\n" + "=" * 70)
    print("📋 最终报告")
    print("=" * 70)

    print(f"\n🎯 审查结论: {result['recommendation']}")
    print(f"📊 统计:")
    print(f"   - 问题发现: {result['summary']['issues_found']}")
    print(f"   - 重构应用: {result['summary']['refactor_applied']}")
    print(f"   - 测试生成: {result['summary']['tests_generated']}")
    print(f"   - 回溯次数: {result['summary']['backtracks']}")

    # 展示记忆系统状态
    print("\n" + "=" * 70)
    print("🧠 Memory System — 向量记忆")
    print("=" * 70)

    stats = await memory.get_stats()
    print(f"\n📊 记忆统计:")
    print(f"   总记录数: {stats['total_memories']}")
    print(f"   独特模式: {stats['unique_patterns']}")
    print(f"   存储大小: {stats['storage_size_kb']:.2f} KB")

    if stats['top_patterns']:
        print(f"\n🔥 高频模式:")
        for pattern in stats['top_patterns'][:5]:
            print(f"      - {pattern['pattern']}: {pattern['frequency']} 次")

    # 相似检索演示
    print(f"\n🔍 相似案例检索 (查询: 'order manager refactoring'):")
    similar = await memory.search("order manager refactoring", top_k=3)
    for i, doc in enumerate(similar, 1):
        print(f"   {i}. 相似度: {doc['similarity']:.4f} | {doc['metadata']}")

    print("\n" + "=" * 70)
    print("✨ Demo 完成! 所有 Agent 协作流程已执行完毕。")
    print("=" * 70)

    return result

if __name__ == "__main__":
    asyncio.run(main())
