"""
Orchestrator: 多 Agent 协作编排器
核心职责：任务分解、Agent 调度、结果聚合、长链推理协调
"""
import asyncio
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from enum import Enum
import json

class TaskStatus(Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    NEEDS_RETRY = "needs_retry"

@dataclass
class TaskNode:
    """任务节点，支持长链推理中的回溯"""
    id: str
    agent_type: str
    input_data: Dict[str, Any]
    output_data: Dict[str, Any] = field(default_factory=dict)
    status: TaskStatus = TaskStatus.PENDING
    reasoning_chain: List[str] = field(default_factory=list)  # CoT 推理链记录
    parent_id: Optional[str] = None
    retry_count: int = 0
    max_retries: int = 3

class Orchestrator:
    """
    多 Agent 编排器

    核心逻辑流：
    1. 接收 PR 审查请求
    2. 分解为 4 个阶段任务（分析→推理→重构→验证）
    3. 按 DAG 依赖调度 Agent 执行
    4. 支持长链推理：验证失败时触发回溯，重新选择策略
    5. 聚合结果生成最终报告
    """

    def __init__(self, agents: Dict[str, Any], memory_store: Any):
        self.agents = agents
        self.memory = memory_store
        self.task_graph: Dict[str, TaskNode] = {}
        self.execution_log: List[Dict] = []

    async def process_pr(self, pr_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        主入口：处理单个 PR 的完整审查流程

        Args:
            pr_data: 包含 repo, branch, diff_files, author 等信息

        Returns:
            完整审查报告，包含所有 Agent 输出和最终决策
        """
        # Phase 1: 初始化任务图（DAG）
        task_id = f"pr_{pr_data['id']}"
        self._build_task_graph(task_id, pr_data)

        # Phase 2: 按拓扑序执行（支持长链推理回溯）
        results = await self._execute_with_cot(task_id)

        # Phase 3: 聚合报告
        report = self._aggregate_report(task_id, results)

        # Phase 4: 存储到记忆系统
        await self._store_memory(task_id, report)

        return report

    def _build_task_graph(self, task_id: str, pr_data: Dict) -> None:
        """构建任务依赖图"""
        # 任务 1: 代码分析（无依赖）
        self.task_graph[f"{task_id}_analyze"] = TaskNode(
            id=f"{task_id}_analyze",
            agent_type="CodeAnalyzer",
            input_data={"pr_data": pr_data, "files": pr_data.get("diff_files", [])}
        )

        # 任务 2: 长链推理（依赖分析结果）
        self.task_graph[f"{task_id}_reason"] = TaskNode(
            id=f"{task_id}_reason",
            agent_type="ChainOfThought",
            input_data={"depends_on": f"{task_id}_analyze"},
            parent_id=f"{task_id}_analyze"
        )

        # 任务 3: 重构执行（依赖推理结果）
        self.task_graph[f"{task_id}_refactor"] = TaskNode(
            id=f"{task_id}_refactor",
            agent_type="RefactorAgent",
            input_data={"depends_on": f"{task_id}_reason"},
            parent_id=f"{task_id}_reason"
        )

        # 任务 4: 测试生成（并行于重构）
        self.task_graph[f"{task_id}_testgen"] = TaskNode(
            id=f"{task_id}_testgen",
            agent_type="TestGenerator",
            input_data={"depends_on": f"{task_id}_reason"},
            parent_id=f"{task_id}_reason"
        )

        # 任务 5: 验证（依赖重构和测试）
        self.task_graph[f"{task_id}_validate"] = TaskNode(
            id=f"{task_id}_validate",
            agent_type="ValidatorAgent",
            input_data={"depends_on": [f"{task_id}_refactor", f"{task_id}_testgen"]},
            parent_id=f"{task_id}_refactor"
        )

    async def _execute_with_cot(self, task_id: str) -> Dict[str, Any]:
        """
        带长链推理的执行引擎

        关键特性：
        - 当 ValidatorAgent 失败时，触发回溯到 ChainOfThought
        - CoT 重新评估策略，选择更保守的重构方案
        - 最多回溯 3 次（避免无限循环）
        """
        results = {}
        stages = ["analyze", "reason", "refactor", "testgen", "validate"]

        for stage in stages:
            node_id = f"{task_id}_{stage}"
            node = self.task_graph[node_id]

            # 执行当前 Agent
            agent = self.agents[node.agent_type]

            # 准备输入：合并前置任务输出
            inputs = self._prepare_inputs(node, results)

            try:
                if stage == "reason":
                    # 长链推理阶段：显式记录推理链
                    output = await agent.execute(inputs, record_chain=True)
                    node.reasoning_chain = output.get("chain", [])
                else:
                    output = await agent.execute(inputs)

                node.output_data = output
                node.status = TaskStatus.COMPLETED
                results[node_id] = output

                # 验证失败处理：触发回溯
                if stage == "validate" and not output.get("passed", False):
                    if node.retry_count < node.max_retries:
                        node.retry_count += 1
                        node.status = TaskStatus.NEEDS_RETRY

                        # 回溯到 reason 阶段，要求重新推理
                        reason_node = self.task_graph[f"{task_id}_reason"]
                        reason_node.output_data["force_conservative"] = True
                        reason_node.output_data["previous_failure"] = output.get("failure_reason")

                        # 重新执行 reason → refactor → validate
                        stages.insert(stages.index("reason") + 1, "refactor")
                        stages.insert(stages.index("reason") + 2, "validate")

                        self.execution_log.append({
                            "event": "backtrack",
                            "from": stage,
                            "to": "reason",
                            "reason": output.get("failure_reason"),
                            "retry": node.retry_count
                        })

            except Exception as e:
                node.status = TaskStatus.FAILED
                results[node_id] = {"error": str(e), "status": "failed"}

        return results

    def _prepare_inputs(self, node: TaskNode, results: Dict) -> Dict[str, Any]:
        """合并前置任务的输出作为当前输入"""
        inputs = {"raw_input": node.input_data}

        if isinstance(node.input_data.get("depends_on"), list):
            for dep_id in node.input_data["depends_on"]:
                if dep_id in results:
                    inputs[dep_id] = results[dep_id]
        elif node.input_data.get("depends_on"):
            dep_id = node.input_data["depends_on"]
            if dep_id in results:
                inputs[dep_id] = results[dep_id]

        return inputs

    def _aggregate_report(self, task_id: str, results: Dict) -> Dict[str, Any]:
        """聚合所有 Agent 输出为最终报告"""
        analyze = results.get(f"{task_id}_analyze", {})
        reason = results.get(f"{task_id}_reason", {})
        refactor = results.get(f"{task_id}_refactor", {})
        testgen = results.get(f"{task_id}_testgen", {})
        validate = results.get(f"{task_id}_validate", {})

        return {
            "pr_id": task_id,
            "summary": {
                "issues_found": len(analyze.get("smells", [])),
                "risk_level": reason.get("risk_level", "unknown"),
                "refactor_applied": refactor.get("changes_applied", 0),
                "tests_generated": testgen.get("tests_count", 0),
                "validation_passed": validate.get("passed", False),
                "backtracks": len([e for e in self.execution_log if e["event"] == "backtrack"])
            },
            "reasoning_chain": reason.get("chain", []),
            "detailed_results": {
                "analysis": analyze,
                "refactor": refactor,
                "tests": testgen,
                "validation": validate
            },
            "execution_log": self.execution_log,
            "recommendation": self._generate_recommendation(reason, validate)
        }

    def _generate_recommendation(self, reason: Dict, validate: Dict) -> str:
        """基于推理结果生成最终建议"""
        if validate.get("passed", False):
            return "✅ 自动审查通过，建议合并"
        elif reason.get("risk_level") == "high":
            return "⚠️ 高风险变更，建议人工深度 Review"
        else:
            return "🔄 部分验证失败，建议查看详细报告后决策"

    async def _store_memory(self, task_id: str, report: Dict) -> None:
        """将审查模式存储到向量记忆系统"""
        # 提取关键特征用于相似性检索
        memory_doc = {
            "id": task_id,
            "content": json.dumps(report["summary"]),
            "metadata": {
                "repo": report.get("repo", "unknown"),
                "author": report.get("author", "unknown"),
                "risk_level": report["summary"]["risk_level"],
                "issues_count": report["summary"]["issues_found"]
            }
        }
        await self.memory.store(memory_doc)
