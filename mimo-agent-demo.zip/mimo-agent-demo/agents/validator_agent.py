"""
ValidatorAgent: 三级验证引擎
单元测试 → 静态分析 → 语义等价性验证
"""
import subprocess
import ast
import difflib
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from enum import Enum

class ValidationLevel(Enum):
    TEST = "test"
    STATIC = "static"
    SEMANTIC = "semantic"

class ValidationResult(Enum):
    PASSED = "passed"
    FAILED = "failed"
    WARNING = "warning"
    SKIPPED = "skipped"

@dataclass
class CheckResult:
    level: ValidationLevel
    result: ValidationResult
    message: str
    details: Dict[str, Any]

class ValidatorAgent:
    """
    验证 Agent

    三级验证体系：
    1. 单元测试验证：运行 pytest，确保所有测试通过
    2. 静态分析验证：运行 pylint/mypy，确保无新增警告
    3. 语义等价性验证：对比重构前后代码的语义行为是否一致

    任一级别失败则阻断流程，触发 Orchestrator 回溯
    """

    def __init__(self):
        self.results: List[CheckResult] = []

    async def execute(self, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """
        执行三级验证

        Args:
            inputs: 包含重构输出和测试代码

        Returns:
            验证结果，包含 passed 标志和失败原因
        """
        self.results = []

        # 获取上游输出
        refactor = inputs.get("pr_refactor", {})
        testgen = inputs.get("pr_testgen", {})
        raw_files = inputs.get("raw_input", {}).get("pr_data", {}).get("diff_files", [])

        # Level 1: 单元测试验证
        test_result = await self._validate_tests(testgen)
        self.results.append(test_result)

        if test_result.result == ValidationResult.FAILED:
            return self._build_failure_response("test", test_result)

        # Level 2: 静态分析验证
        static_result = await self._validate_static_analysis(raw_files)
        self.results.append(static_result)

        if static_result.result == ValidationResult.FAILED:
            return self._build_failure_response("static", static_result)

        # Level 3: 语义等价性验证
        semantic_result = await self._validate_semantic_equivalence(raw_files, refactor)
        self.results.append(semantic_result)

        if semantic_result.result == ValidationResult.FAILED:
            return self._build_failure_response("semantic", semantic_result)

        # 全部通过
        return {
            "passed": True,
            "validation_level": "all",
            "checks": [self._result_to_dict(r) for r in self.results],
            "summary": {
                "tests_passed": test_result.details.get("passed_count", 0),
                "tests_total": test_result.details.get("total_count", 0),
                "static_warnings": static_result.details.get("warning_count", 0),
                "semantic_score": semantic_result.details.get("similarity_score", 1.0)
            }
        }

    async def _validate_tests(self, testgen: Dict) -> CheckResult:
        """Level 1: 运行单元测试"""
        pytest_code = testgen.get("pytest_code", "")

        if not pytest_code:
            return CheckResult(
                level=ValidationLevel.TEST,
                result=ValidationResult.SKIPPED,
                message="无测试代码，跳过测试验证",
                details={"reason": "no_tests_generated"}
            )

        # 实际部署中写入临时文件并运行 pytest
        # 此处模拟验证结果
        try:
            # 语法检查
            ast.parse(pytest_code)

            return CheckResult(
                level=ValidationLevel.TEST,
                result=ValidationResult.PASSED,
                message="测试代码语法正确，结构完整",
                details={
                    "passed_count": testgen.get("tests_count", 0),
                    "total_count": testgen.get("tests_count", 0),
                    "coverage_estimate": testgen.get("coverage_estimate", {})
                }
            )
        except SyntaxError as e:
            return CheckResult(
                level=ValidationLevel.TEST,
                result=ValidationResult.FAILED,
                message=f"测试代码存在语法错误: {str(e)}",
                details={"error": str(e), "line": getattr(e, 'lineno', 0)}
            )

    async def _validate_static_analysis(self, files: List[Dict]) -> CheckResult:
        """Level 2: 静态分析检查"""
        warnings = []

        for file_info in files:
            content = file_info.get("content", "")
            path = file_info.get("path", "")

            if not content or not path.endswith(".py"):
                continue

            # 基础静态检查
            try:
                tree = ast.parse(content)

                # 检查未使用的变量
                for node in ast.walk(tree):
                    if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Store):
                        # 简化检查：实际应使用更复杂的分析
                        pass

            except SyntaxError:
                warnings.append(f"{path}: 语法错误")

        if warnings:
            return CheckResult(
                level=ValidationLevel.STATIC,
                result=ValidationResult.WARNING,
                message=f"发现 {len(warnings)} 个静态分析警告",
                details={"warnings": warnings, "warning_count": len(warnings)}
            )

        return CheckResult(
            level=ValidationLevel.STATIC,
            result=ValidationResult.PASSED,
            message="静态分析通过，无新增警告",
            details={"warning_count": 0}
        )

    async def _validate_semantic_equivalence(self, files: List[Dict], refactor: Dict) -> CheckResult:
        """Level 3: 语义等价性验证"""
        changes = refactor.get("changes", [])

        if not changes:
            return CheckResult(
                level=ValidationLevel.SEMANTIC,
                result=ValidationResult.PASSED,
                message="无重构变更，语义等价性自然成立",
                details={"similarity_score": 1.0}
            )

        # 检查变更的安全级别
        risky_changes = [c for c in changes if c.get("safety") == "risky"]
        moderate_changes = [c for c in changes if c.get("safety") == "moderate"]

        if risky_changes:
            # 高风险变更需要更严格的验证
            return CheckResult(
                level=ValidationLevel.SEMANTIC,
                result=ValidationResult.WARNING,
                message=f"包含 {len(risky_changes)} 个高风险变更，建议人工确认",
                details={
                    "similarity_score": 0.7,
                    "risky_count": len(risky_changes),
                    "moderate_count": len(moderate_changes)
                }
            )

        # 计算代码相似度（简化版）
        similarity = self._calculate_similarity(files, changes)

        if similarity < 0.6:
            return CheckResult(
                level=ValidationLevel.SEMANTIC,
                result=ValidationResult.FAILED,
                message=f"语义相似度 {similarity:.2f} 低于阈值 0.6，可能存在行为变更",
                details={"similarity_score": similarity, "threshold": 0.6}
            )

        return CheckResult(
            level=ValidationLevel.SEMANTIC,
            result=ValidationResult.PASSED,
            message=f"语义相似度 {similarity:.2f}，重构保持行为一致性",
            details={"similarity_score": similarity}
        )

    def _calculate_similarity(self, files: List[Dict], changes: List[Dict]) -> float:
        """计算重构前后的代码相似度"""
        # 简化版：基于变更数量和类型的启发式评分
        total_changes = len(changes)
        safe_changes = len([c for c in changes if c.get("safety") == "safe"])

        if total_changes == 0:
            return 1.0

        # 安全变更权重高，风险变更权重低
        score = (safe_changes * 1.0 + (total_changes - safe_changes) * 0.5) / total_changes
        return round(score, 2)

    def _build_failure_response(self, level: str, result: CheckResult) -> Dict[str, Any]:
        """构建失败响应，触发 Orchestrator 回溯"""
        return {
            "passed": False,
            "failed_level": level,
            "failure_reason": result.message,
            "details": result.details,
            "checks": [self._result_to_dict(r) for r in self.results],
            "recommendation": self._failure_recommendation(level, result)
        }

    def _failure_recommendation(self, level: str, result: CheckResult) -> str:
        """生成失败时的建议"""
        recommendations = {
            "test": "测试失败：检查重构是否破坏了原有逻辑，或测试用例是否需要更新",
            "static": "静态分析失败：修复代码风格问题或类型错误",
            "semantic": "语义验证失败：重构可能改变了代码行为，建议使用更保守的策略"
        }
        return recommendations.get(level, "未知错误，建议人工审查")

    def _result_to_dict(self, result: CheckResult) -> Dict[str, Any]:
        return {
            "level": result.level.value,
            "result": result.result.value,
            "message": result.message,
            "details": result.details
        }
