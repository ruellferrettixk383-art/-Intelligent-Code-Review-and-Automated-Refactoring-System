"""
RefactorAgent: 自动化代码重构执行器
支持规则驱动的安全重构和 LLM 驱动的复杂重构
"""
import re
import ast
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from enum import Enum

class RefactorType(Enum):
    EXTRACT_METHOD = "extract_method"
    RENAME_VARIABLE = "rename_variable"
    REMOVE_UNUSED_IMPORT = "remove_unused_import"
    ADD_TYPE_HINT = "add_type_hint"
    GUARD_CLAUSE = "guard_clause"
    EXTRACT_CLASS = "extract_class"

@dataclass
class CodeChange:
    file_path: str
    change_type: RefactorType
    original_code: str
    new_code: str
    line_start: int
    line_end: int
    description: str
    safety_level: str  # safe, moderate, risky

class RefactorAgent:
    """
    重构执行 Agent

    双模式架构：
    1. 规则引擎模式：执行安全的语法级重构（Rename/Extract/Remove）
    2. LLM 生成模式：处理复杂的语义级重构（需要理解业务逻辑）

    所有变更生成统一 Diff 格式，便于下游验证
    """

    def __init__(self, llm_client: Optional[Any] = None):
        self.llm = llm_client
        self.changes: List[CodeChange] = []

    async def execute(self, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """
        执行重构计划

        Args:
            inputs: 包含 reasoning.plan 和原始文件内容

        Returns:
            变更列表和统一 Diff 格式输出
        """
        plan = inputs.get("pr_reason", {}).get("plan", [])
        raw_files = inputs.get("raw_input", {}).get("pr_data", {}).get("diff_files", [])

        self.changes = []
        file_contents = {f["path"]: f.get("content", "") for f in raw_files}

        for item in plan:
            action = item.get("action", "")
            target = item.get("target", "")

            # 解析 target: "path/to/file.py:line"
            parts = target.rsplit(":", 1)
            file_path = parts[0]
            line_num = int(parts[1]) if len(parts) > 1 and parts[1].isdigit() else 0

            content = file_contents.get(file_path, "")
            if not content:
                continue

            # 根据 action 类型选择重构策略
            if action in ["extract_method", "extract_class"]:
                change = await self._rule_based_refactor(action, file_path, content, line_num, item)
            elif action in ["remove_import", "rename_variable"]:
                change = await self._safe_refactor(action, file_path, content, line_num, item)
            elif action in ["guard_clauses", "dependency_inversion"]:
                change = await self._llm_assisted_refactor(action, file_path, content, line_num, item)
            else:
                change = await self._generate_suggestion(action, file_path, content, line_num, item)

            if change:
                self.changes.append(change)
                # 更新文件内容以支持链式重构
                file_contents[file_path] = self._apply_change(content, change)

        return {
            "changes_applied": len(self.changes),
            "changes": [self._change_to_dict(c) for c in self.changes],
            "diff_output": self._generate_unified_diff(file_contents, raw_files),
            "safety_summary": self._safety_summary()
        }

    async def _safe_refactor(self, action: str, file_path: str, content: str, 
                             line_num: int, item: Dict) -> Optional[CodeChange]:
        """安全重构：无业务逻辑理解要求"""
        lines = content.split("\n")

        if action == "remove_import":
            # 删除未使用的导入行
            if 0 < line_num <= len(lines):
                original = lines[line_num - 1]
                new_content = "\n".join(lines[:line_num-1] + lines[line_num:])
                return CodeChange(
                    file_path=file_path,
                    change_type=RefactorType.REMOVE_UNUSED_IMPORT,
                    original_code=original,
                    new_code="",
                    line_start=line_num,
                    line_end=line_num,
                    description=item.get("description", "移除未使用导入"),
                    safety_level="safe"
                )

        elif action == "rename_variable":
            # 重命名不规范的变量（示例：简化版）
            # 实际应使用 AST 精确替换
            return CodeChange(
                file_path=file_path,
                change_type=RefactorType.RENAME_VARIABLE,
                original_code="# 变量重命名需要 AST 精确匹配",
                new_code="# 已生成重命名建议",
                line_start=line_num,
                line_end=line_num,
                description=item.get("description", "变量重命名"),
                safety_level="moderate"
            )

        return None

    async def _rule_based_refactor(self, action: str, file_path: str, content: str,
                                    line_num: int, item: Dict) -> Optional[CodeChange]:
        """基于规则的重构：需要 AST 解析"""
        try:
            tree = ast.parse(content)
            lines = content.split("\n")

            if action == "extract_method":
                # 找到目标函数/方法
                for node in ast.walk(tree):
                    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                        if node.lineno <= line_num <= (node.end_lineno or node.lineno):
                            # 提取逻辑块（简化示例）
                            original = "\n".join(lines[node.lineno-1:node.end_lineno])

                            # 生成提取后的代码（简化版）
                            new_code = self._generate_extracted_method(node, lines)

                            return CodeChange(
                                file_path=file_path,
                                change_type=RefactorType.EXTRACT_METHOD,
                                original_code=original,
                                new_code=new_code,
                                line_start=node.lineno,
                                line_end=node.end_lineno or node.lineno,
                                description=item.get("description", "提取方法"),
                                safety_level="moderate"
                            )

            elif action == "extract_class":
                # 类拆分逻辑（简化）
                for node in ast.walk(tree):
                    if isinstance(node, ast.ClassDef):
                        if node.lineno <= line_num <= (node.end_lineno or node.lineno):
                            return CodeChange(
                                file_path=file_path,
                                change_type=RefactorType.EXTRACT_CLASS,
                                original_code=f"class {node.name}:",
                                new_code=f"# 建议将 {node.name} 拆分为多个职责单一的类",
                                line_start=node.lineno,
                                line_end=node.lineno,
                                description=item.get("description", "提取类"),
                                safety_level="risky"
                            )

        except SyntaxError:
            pass

        return None

    async def _llm_assisted_refactor(self, action: str, file_path: str, content: str,
                                      line_num: int, item: Dict) -> Optional[CodeChange]:
        """LLM 辅助重构：处理需要语义理解的复杂场景"""
        # 实际部署中调用 LLM API
        # 此处生成结构化建议

        if action == "guard_clauses":
            lines = content.split("\n")
            if line_num <= len(lines):
                original = lines[line_num - 1]
                # 生成 Guard Clause 建议
                new_code = f"if not condition:\n    return\n{original}"

                return CodeChange(
                    file_path=file_path,
                    change_type=RefactorType.GUARD_CLAUSE,
                    original_code=original,
                    new_code=new_code,
                    line_start=line_num,
                    line_end=line_num,
                    description=item.get("description", "应用 Guard Clause 减少嵌套"),
                    safety_level="moderate"
                )

        elif action == "dependency_inversion":
            return CodeChange(
                file_path=file_path,
                change_type=RefactorType.ADD_TYPE_HINT,
                original_code="# 循环导入问题",
                new_code="# 建议: 1. 提取共享接口 2. 使用依赖注入 3. 延迟导入",
                line_start=line_num,
                line_end=line_num,
                description=item.get("description", "解决循环导入"),
                safety_level="risky"
            )

        return None

    async def _generate_suggestion(self, action: str, file_path: str, content: str,
                                    line_num: int, item: Dict) -> Optional[CodeChange]:
        """生成人工审查建议（无法自动重构时）"""
        return CodeChange(
            file_path=file_path,
            change_type=RefactorType.ADD_TYPE_HINT,
            original_code="# 需要人工审查",
            new_code=f"# 建议: {item.get('description', '查看详细报告')}",
            line_start=line_num,
            line_end=line_num,
            description=f"[需人工] {item.get('description', '')}",
            safety_level="safe"
        )

    def _generate_extracted_method(self, node: ast.FunctionDef, lines: List[str]) -> str:
        """生成提取方法后的代码（简化版）"""
        method_name = f"_extracted_from_{node.name}"
        original_body = "\n".join(lines[node.lineno:node.end_lineno])

        return f"""def {method_name}():
    # 提取的逻辑块
    {original_body}

# 原方法调用新提取的方法
def {node.name}(...):
    {method_name}()
"""

    def _apply_change(self, content: str, change: CodeChange) -> str:
        """将变更应用到内容（用于链式重构）"""
        lines = content.split("\n")
        new_lines = lines[:change.line_start - 1]
        new_lines.extend(change.new_code.split("\n"))
        new_lines.extend(lines[change.line_end:])
        return "\n".join(new_lines)

    def _generate_unified_diff(self, new_contents: Dict[str, str], original_files: List[Dict]) -> str:
        """生成统一 Diff 格式"""
        diff_lines = []

        for file_info in original_files:
            path = file_info["path"]
            original = file_info.get("content", "")
            new = new_contents.get(path, original)

            if original != new:
                diff_lines.append(f"diff --git a/{path} b/{path}")
                diff_lines.append("--- a/" + path)
                diff_lines.append("+++ b/" + path)

                # 简化 diff 生成（实际应使用 difflib）
                diff_lines.append("@@ -1 +1 @@")
                diff_lines.append(f"-{original.split(chr(10))[0] if original else ''}")
                diff_lines.append(f"+{new.split(chr(10))[0] if new else ''}")
                diff_lines.append("")

        return "\n".join(diff_lines)

    def _safety_summary(self) -> Dict[str, int]:
        """安全级别统计"""
        summary = {"safe": 0, "moderate": 0, "risky": 0}
        for c in self.changes:
            summary[c.safety_level] = summary.get(c.safety_level, 0) + 1
        return summary

    def _change_to_dict(self, change: CodeChange) -> Dict[str, Any]:
        return {
            "file": change.file_path,
            "type": change.change_type.value,
            "lines": f"{change.line_start}-{change.line_end}",
            "description": change.description,
            "safety": change.safety_level,
            "diff": {
                "original": change.original_code[:200] + "..." if len(change.original_code) > 200 else change.original_code,
                "new": change.new_code[:200] + "..." if len(change.new_code) > 200 else change.new_code
            }
        }
