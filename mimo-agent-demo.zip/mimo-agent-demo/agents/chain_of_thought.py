"""
ChainOfThought Engine: 长链推理引擎
核心能力：多步推理、策略选择、自我纠错
"""
import json
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, field
from enum import Enum

class ReasoningStep(Enum):
    PROBLEM_IDENTIFICATION = "problem_identification"
    ROOT_CAUSE_ANALYSIS = "root_cause_analysis"
    IMPACT_ASSESSMENT = "impact_assessment"
    STRATEGY_SELECTION = "strategy_selection"
    PLAN_GENERATION = "plan_generation"
    SELF_CORRECTION = "self_correction"

@dataclass
class ReasoningNode:
    step: ReasoningStep
    thought: str
    evidence: List[str]
    confidence: float
    next_steps: List[str] = field(default_factory=list)

class ChainOfThought:
    """
    长链推理引擎

    核心逻辑：
    1. 接收 CodeAnalyzer 的输出（坏味道列表）
    2. 执行 5 步推理链：
       - 问题识别：确认关键问题
       - 根因分析：分析问题产生原因
       - 影响评估：评估修复影响面
       - 策略选择：在保守/激进/跳过中选择
       - 方案生成：输出具体重构计划
    3. 支持自我纠错：当验证失败时回溯并调整策略

    与 LLM 集成：实际部署中调用 LLM API 进行推理，此处展示结构化框架
    """

    def __init__(self, llm_client: Optional[Any] = None):
        self.llm = llm_client
        self.reasoning_chain: List[ReasoningNode] = []

    async def execute(self, inputs: Dict[str, Any], record_chain: bool = True) -> Dict[str, Any]:
        """
        执行长链推理

        Args:
            inputs: 包含上游分析结果
            record_chain: 是否记录推理链（用于回溯调试）

        Returns:
            包含 risk_level, strategy, plan, chain 的输出
        """
        # 获取上游分析结果
        analyze_result = inputs.get("pr_analyze", {})
        smells = analyze_result.get("smells", [])
        risk_score = analyze_result.get("risk_score", 0)

        # 检查是否需要保守策略（来自回溯信号）
        force_conservative = inputs.get("raw_input", {}).get("force_conservative", False)
        previous_failure = inputs.get("raw_input", {}).get("previous_failure")

        # 清空历史链（如果是回溯重试）
        if force_conservative:
            self.reasoning_chain = []

        # Step 1: 问题识别
        step1 = self._step_problem_identification(smells)

        # Step 2: 根因分析
        step2 = self._step_root_cause_analysis(step1)

        # Step 3: 影响评估
        step3 = self._step_impact_assessment(step2, smells)

        # Step 4: 策略选择（受保守模式影响）
        step4 = self._step_strategy_selection(step3, risk_score, force_conservative)

        # Step 5: 方案生成
        step5 = self._step_plan_generation(step4, smells)

        # 自我纠错检查
        if previous_failure:
            step6 = self._step_self_correction(step5, previous_failure)
            self.reasoning_chain.append(step6)
            # 基于纠错结果重新生成方案
            step5 = self._regenerate_plan(step6, step4)

        # 组装输出
        result = {
            "risk_level": self._determine_risk_level(risk_score, step3),
            "strategy": step4.thought,
            "plan": self._format_plan(step5),
            "chain": [self._node_to_dict(n) for n in self.reasoning_chain] if record_chain else [],
            "estimated_tokens": self._estimate_tokens(),
            "backtrack_signal": force_conservative
        }

        return result

    def _step_problem_identification(self, smells: List[Dict]) -> ReasoningNode:
        """步骤 1: 识别关键问题"""
        critical = [s for s in smells if s.get("severity") == "critical"]
        high = [s for s in smells if s.get("severity") == "high"]

        thought = (
            f"识别到 {len(critical)} 个关键问题，{len(high)} 个高优先级问题。"
            f"最严重的是: {critical[0]['description'] if critical else high[0]['description'] if high else '无明显严重问题'}"
        )

        node = ReasoningNode(
            step=ReasoningStep.PROBLEM_IDENTIFICATION,
            thought=thought,
            evidence=[s["description"] for s in critical + high[:3]],
            confidence=0.95 if critical else 0.8
        )
        self.reasoning_chain.append(node)
        return node

    def _step_root_cause_analysis(self, prev: ReasoningNode) -> ReasoningNode:
        """步骤 2: 分析根因"""
        # 基于问题类型推断根因
        evidence = prev.evidence
        root_causes = []

        for desc in evidence:
            if "God Class" in desc or "方法" in desc:
                root_causes.append("缺乏单一职责原则的应用")
            if "循环导入" in desc:
                root_causes.append("模块间耦合度过高")
            if "嵌套" in desc:
                root_causes.append("缺乏早期返回模式")

        thought = (
            f"根因分析: {', '.join(root_causes) if root_causes else '代码规范执行不严格'}。"
            f"这些问题通常源于快速迭代中缺乏重构窗口期。"
        )

        node = ReasoningNode(
            step=ReasoningStep.ROOT_CAUSE_ANALYSIS,
            thought=thought,
            evidence=root_causes,
            confidence=0.85
        )
        self.reasoning_chain.append(node)
        return node

    def _step_impact_assessment(self, prev: ReasoningNode, smells: List[Dict]) -> ReasoningNode:
        """步骤 3: 评估影响面"""
        files_affected = set(s.get("file") for s in smells)

        # 估算影响范围
        if len(files_affected) > 5:
            impact = "广泛影响"
            confidence = 0.7
        elif len(files_affected) > 2:
            impact = "中等影响"
            confidence = 0.85
        else:
            impact = "局部影响"
            confidence = 0.95

        thought = (
            f"影响评估: 涉及 {len(files_affected)} 个文件，属于{impact}。"
            f"重构可能需要更新 {len(files_affected) * 2} 个测试用例。"
        )

        node = ReasoningNode(
            step=ReasoningStep.IMPACT_ASSESSMENT,
            thought=thought,
            evidence=list(files_affected),
            confidence=confidence
        )
        self.reasoning_chain.append(node)
        return node

    def _step_strategy_selection(
        self, 
        prev: ReasoningNode, 
        risk_score: float,
        force_conservative: bool
    ) -> ReasoningNode:
        """步骤 4: 选择重构策略"""

        if force_conservative:
            strategy = "conservative"
            thought = (
                "【回溯模式】前次重构验证失败，切换为保守策略。"
                "仅执行安全的 Rename/Extract Method，避免结构变更。"
            )
            confidence = 0.9
        elif risk_score > 0.7:
            strategy = "incremental"
            thought = (
                "高风险评分(>0.7)，选择增量重构策略。"
                "分 3 个阶段执行：先提取方法→再拆分类→最后优化导入。"
                "每个阶段独立验证。"
            )
            confidence = 0.8
        elif risk_score > 0.4:
            strategy = "standard"
            thought = (
                "中等风险，采用标准重构流程。"
                "按优先级排序：关键问题优先，高优先级次之。"
            )
            confidence = 0.9
        else:
            strategy = "aggressive"
            thought = (
                "低风险场景，可以执行激进重构。"
                "一次性解决所有检测到的问题，包括低优先级优化。"
            )
            confidence = 0.95

        node = ReasoningNode(
            step=ReasoningStep.STRATEGY_SELECTION,
            thought=thought,
            evidence=[f"risk_score={risk_score}", f"force_conservative={force_conservative}"],
            confidence=confidence
        )
        self.reasoning_chain.append(node)
        return node

    def _step_plan_generation(self, prev: ReasoningNode, smells: List[Dict]) -> ReasoningNode:
        """步骤 5: 生成具体重构计划"""
        strategy = prev.thought

        # 根据策略生成不同粒度的计划
        plan_items = []

        if "conservative" in strategy:
            # 保守模式：只做安全重构
            for s in smells[:2]:  # 仅处理最严重的前 2 个
                if s.get("type") in ["long_method", "unused_import"]:
                    plan_items.append({
                        "action": "extract_method",
                        "target": f"{s['file']}:{s['line']}",
                        "description": s["suggestion"]
                    })
        else:
            # 标准/激进模式：全面重构
            for s in smells:
                plan_items.append({
                    "action": self._map_smell_to_action(s.get("type", "")),
                    "target": f"{s['file']}:{s['line']}",
                    "description": s["suggestion"],
                    "severity": s.get("severity")
                })

        thought = (
            f"生成重构计划: 共 {len(plan_items)} 项操作。"
            f"策略: {strategy}。预计耗时: {len(plan_items) * 5} 分钟。"
        )

        node = ReasoningNode(
            step=ReasoningStep.PLAN_GENERATION,
            thought=thought,
            evidence=[json.dumps(p) for p in plan_items[:5]],
            confidence=prev.confidence * 0.95
        )
        self.reasoning_chain.append(node)
        return node

    def _step_self_correction(self, prev: ReasoningNode, failure_reason: str) -> ReasoningNode:
        """步骤 6: 自我纠错（回溯时触发）"""
        thought = (
            f"【自我纠错】前次失败原因: {failure_reason}。"
            f"分析: 可能是重构粒度太大或边界条件未覆盖。"
            f"调整: 缩小重构范围，增加前置条件检查。"
        )

        node = ReasoningNode(
            step=ReasoningStep.SELF_CORRECTION,
            thought=thought,
            evidence=[failure_reason],
            confidence=0.85
        )
        return node

    def _regenerate_plan(self, correction: ReasoningNode, original_strategy: ReasoningNode) -> ReasoningNode:
        """基于纠错结果重新生成计划"""
        thought = (
            f"【重新生成】基于纠错反馈调整计划。"
            f"保留已通过验证的部分，仅重试失败项。"
            f"增加额外的安全检查和回滚点。"
        )

        node = ReasoningNode(
            step=ReasoningStep.PLAN_GENERATION,
            thought=thought,
            evidence=["regenerated_from_correction"],
            confidence=correction.confidence * 0.9
        )
        return node

    def _map_smell_to_action(self, smell_type: str) -> str:
        """将坏味道映射到重构动作"""
        mapping = {
            "god_class": "extract_class",
            "long_method": "extract_method",
            "circular_import": "dependency_inversion",
            "deep_nesting": "guard_clauses",
            "unused_import": "remove_import",
            "bare_except": "specify_exception"
        }
        return mapping.get(smell_type, "review_manually")

    def _determine_risk_level(self, risk_score: float, impact_step: ReasoningNode) -> str:
        """确定风险等级"""
        if risk_score > 0.8:
            return "critical"
        elif risk_score > 0.6:
            return "high"
        elif risk_score > 0.3:
            return "medium"
        return "low"

    def _format_plan(self, step: ReasoningNode) -> List[Dict]:
        """格式化重构计划"""
        try:
            # 从 evidence 中解析计划项
            items = []
            for ev in step.evidence:
                if ev.startswith("{"):
                    items.append(json.loads(ev))
            return items
        except:
            return [{"action": "review", "description": step.thought}]

    def _estimate_tokens(self) -> int:
        """估算本次推理消耗的 Token 数"""
        total_chars = sum(len(n.thought) + sum(len(e) for e in n.evidence) for n in self.reasoning_chain)
        return total_chars // 4  # 粗略估算：1 token ≈ 4 字符

    def _node_to_dict(self, node: ReasoningNode) -> Dict[str, Any]:
        return {
            "step": node.step.value,
            "thought": node.thought,
            "evidence": node.evidence,
            "confidence": node.confidence
        }
