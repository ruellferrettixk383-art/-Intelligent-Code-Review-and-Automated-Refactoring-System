"""
CodeAnalyzer Agent: 基于 AST 的静态代码分析
检测代码坏味道，输出结构化风险报告
"""
import ast
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from enum import Enum

class SmellType(Enum):
    GOD_CLASS = "god_class"
    LONG_METHOD = "long_method"
    CIRCULAR_IMPORT = "circular_import"
    DEEP_NESTING = "deep_nesting"
    MAGIC_NUMBER = "magic_number"
    DUPLICATED_CODE = "duplicated_code"
    UNUSED_IMPORT = "unused_import"
    BARE_EXCEPT = "bare_except"

@dataclass
class CodeSmell:
    smell_type: SmellType
    file_path: str
    line_number: int
    severity: str  # critical, high, medium, low
    description: str
    suggestion: str
    confidence: float  # 0.0 - 1.0

class CodeAnalyzer:
    """
    代码分析 Agent

    核心能力：
    1. AST 解析：精确识别代码结构
    2. 坏味道检测：覆盖 8 大类常见问题
    3. 影响面评估：分析依赖关系和变更传播
    4. 结构化输出：为下游 Agent 提供标准化输入
    """

    # 阈值配置
    THRESHOLDS = {
        "max_class_methods": 20,
        "max_method_lines": 50,
        "max_nesting_depth": 4,
        "max_cyclomatic_complexity": 15
    }

    def __init__(self):
        self.smells: List[CodeSmell] = []
        self.ast_cache: Dict[str, ast.AST] = {}

    async def execute(self, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """
        Agent 执行入口

        Args:
            inputs: 包含 pr_data.files 的输入数据

        Returns:
            结构化分析报告
        """
        files = inputs.get("pr_data", {}).get("diff_files", [])
        self.smells = []

        for file_info in files:
            await self._analyze_file(file_info)

        # 依赖分析：检测循环导入
        await self._detect_circular_imports(files)

        return {
            "smells": [self._smell_to_dict(s) for s in self.smells],
            "summary": self._generate_summary(),
            "risk_score": self._calculate_risk_score(),
            "files_analyzed": len(files)
        }

    async def _analyze_file(self, file_info: Dict[str, Any]) -> None:
        """分析单个文件"""
        file_path = file_info.get("path", "")
        content = file_info.get("content", "")

        if not content or not file_path.endswith(".py"):
            return

        try:
            tree = ast.parse(content)
            self.ast_cache[file_path] = tree

            # 遍历 AST 节点
            for node in ast.walk(tree):
                if isinstance(node, ast.ClassDef):
                    self._check_god_class(node, file_path)
                    self._check_class_complexity(node, file_path, content)
                elif isinstance(node, ast.FunctionDef) or isinstance(node, ast.AsyncFunctionDef):
                    self._check_long_method(node, file_path, content)
                    self._check_nesting_depth(node, file_path)
                elif isinstance(node, ast.ExceptHandler):
                    self._check_bare_except(node, file_path)

            # 检查未使用的导入
            self._check_unused_imports(tree, file_path)

        except SyntaxError:
            self.smells.append(CodeSmell(
                smell_type=SmellType.DUPLICATED_CODE,
                file_path=file_path,
                line_number=0,
                severity="high",
                description="文件存在语法错误，无法解析",
                suggestion="修复语法错误后再提交",
                confidence=1.0
            ))

    def _check_god_class(self, node: ast.ClassDef, file_path: str) -> None:
        """检测 God Class：方法过多的类"""
        method_count = len([n for n in node.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))])

        if method_count > self.THRESHOLDS["max_class_methods"]:
            self.smells.append(CodeSmell(
                smell_type=SmellType.GOD_CLASS,
                file_path=file_path,
                line_number=node.lineno,
                severity="critical" if method_count > 30 else "high",
                description=f"类 '{node.name}' 包含 {method_count} 个方法，超过阈值 {self.THRESHOLDS['max_class_methods']}",
                suggestion="应用 Extract Class 或 Extract Subclass 重构，按职责拆分",
                confidence=min(0.95, method_count / 50)
            ))

    def _check_long_method(self, node: ast.FunctionDef, file_path: str, content: str) -> None:
        """检测长方法"""
        lines = content.split("\n")
        start_line = node.lineno - 1
        end_line = node.end_lineno or start_line + 1
        method_lines = end_line - start_line

        if method_lines > self.THRESHOLDS["max_method_lines"]:
            self.smells.append(CodeSmell(
                smell_type=SmellType.LONG_METHOD,
                file_path=file_path,
                line_number=node.lineno,
                severity="high" if method_lines > 80 else "medium",
                description=f"方法 '{node.name}' 长达 {method_lines} 行",
                suggestion="应用 Extract Method 重构，将独立逻辑块提取为新方法",
                confidence=min(0.9, method_lines / 100)
            ))

    def _check_nesting_depth(self, node: ast.FunctionDef, file_path: str) -> None:
        """检测嵌套深度"""
        max_depth = self._calculate_nesting_depth(node)

        if max_depth > self.THRESHOLDS["max_nesting_depth"]:
            self.smells.append(CodeSmell(
                smell_type=SmellType.DEEP_NESTING,
                file_path=file_path,
                line_number=node.lineno,
                severity="medium",
                description=f"方法 '{node.name}' 最大嵌套深度 {max_depth}",
                suggestion="应用 Guard Clauses 或 Extract Method 减少嵌套",
                confidence=0.85
            ))

    def _calculate_nesting_depth(self, node: ast.AST, current_depth: int = 0) -> int:
        """递归计算嵌套深度"""
        max_depth = current_depth

        for child in ast.iter_child_nodes(node):
            if isinstance(child, (ast.If, ast.For, ast.While, ast.With, ast.Try)):
                child_depth = self._calculate_nesting_depth(child, current_depth + 1)
                max_depth = max(max_depth, child_depth)
            else:
                child_depth = self._calculate_nesting_depth(child, current_depth)
                max_depth = max(max_depth, child_depth)

        return max_depth

    def _check_bare_except(self, node: ast.ExceptHandler, file_path: str) -> None:
        """检测裸 except"""
        if node.type is None:
            self.smells.append(CodeSmell(
                smell_type=SmellType.BARE_EXCEPT,
                file_path=file_path,
                line_number=node.lineno,
                severity="high",
                description="使用裸 except 会捕获所有异常包括 KeyboardInterrupt",
                suggestion="指定具体的异常类型，如 except ValueError:",
                confidence=0.95
            ))

    def _check_unused_imports(self, tree: ast.AST, file_path: str) -> None:
        """检测未使用的导入"""
        imports = {}
        used_names = set()

        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    imports[alias.asname or alias.name] = node.lineno
            elif isinstance(node, ast.ImportFrom):
                for alias in node.names:
                    imports[alias.asname or alias.name] = node.lineno
            elif isinstance(node, ast.Name):
                used_names.add(node.id)

        for name, line in imports.items():
            if name not in used_names and not name.startswith("_"):
                self.smells.append(CodeSmell(
                    smell_type=SmellType.UNUSED_IMPORT,
                    file_path=file_path,
                    line_number=line,
                    severity="low",
                    description=f"未使用的导入: {name}",
                    suggestion=f"删除 import {name} 或使用 __all__ 显式导出",
                    confidence=0.9
                ))

    def _check_class_complexity(self, node: ast.ClassDef, file_path: str, content: str) -> None:
        """计算类圈复杂度"""
        complexity = 1
        for child in ast.walk(node):
            if isinstance(child, (ast.If, ast.While, ast.For, ast.ExceptHandler)):
                complexity += 1
            elif isinstance(child, ast.BoolOp):
                complexity += len(child.values) - 1

        if complexity > self.THRESHOLDS["max_cyclomatic_complexity"]:
            self.smells.append(CodeSmell(
                smell_type=SmellType.MAGIC_NUMBER,
                file_path=file_path,
                line_number=node.lineno,
                severity="medium",
                description=f"类 '{node.name}' 圈复杂度 {complexity}",
                suggestion="简化条件逻辑，提取复杂判断为独立方法",
                confidence=0.8
            ))

    async def _detect_circular_imports(self, files: List[Dict]) -> None:
        """检测循环导入（跨文件分析）"""
        import_graph = {}

        for file_info in files:
            path = file_info.get("path", "")
            tree = self.ast_cache.get(path)
            if not tree:
                continue

            imports = []
            for node in ast.walk(tree):
                if isinstance(node, ast.ImportFrom):
                    module = node.module or ""
                    imports.append(module)
            import_graph[path] = imports

        # 简单的循环检测（实际应使用图算法）
        for path, imports in import_graph.items():
            for imp in imports:
                imp_file = imp.replace(".", "/") + ".py"
                if imp_file in import_graph:
                    if path in import_graph.get(imp_file, []):
                        self.smells.append(CodeSmell(
                            smell_type=SmellType.CIRCULAR_IMPORT,
                            file_path=path,
                            line_number=1,
                            severity="critical",
                            description=f"检测到循环导入: {path} <-> {imp_file}",
                            suggestion="应用 Dependency Inversion 或提取共享接口",
                            confidence=0.9
                        ))

    def _smell_to_dict(self, smell: CodeSmell) -> Dict[str, Any]:
        return {
            "type": smell.smell_type.value,
            "file": smell.file_path,
            "line": smell.line_number,
            "severity": smell.severity,
            "description": smell.description,
            "suggestion": smell.suggestion,
            "confidence": smell.confidence
        }

    def _generate_summary(self) -> Dict[str, Any]:
        """生成统计摘要"""
        severity_count = {"critical": 0, "high": 0, "medium": 0, "low": 0}
        for smell in self.smells:
            severity_count[smell.severity] = severity_count.get(smell.severity, 0) + 1

        return {
            "total_issues": len(self.smells),
            "severity_distribution": severity_count,
            "top_files": self._get_top_files(),
            "most_common": self._get_most_common_smells()
        }

    def _get_top_files(self, limit: int = 5) -> List[Dict]:
        """获取问题最多的文件"""
        file_counts = {}
        for smell in self.smells:
            file_counts[smell.file_path] = file_counts.get(smell.file_path, 0) + 1
        return [
            {"file": f, "issues": c} 
            for f, c in sorted(file_counts.items(), key=lambda x: -x[1])[:limit]
        ]

    def _get_most_common_smells(self, limit: int = 3) -> List[Dict]:
        """获取最常见的坏味道类型"""
        type_counts = {}
        for smell in self.smells:
            type_counts[smell.smell_type.value] = type_counts.get(smell.smell_type.value, 0) + 1
        return [
            {"type": t, "count": c} 
            for t, c in sorted(type_counts.items(), key=lambda x: -x[1])[:limit]
        ]

    def _calculate_risk_score(self) -> float:
        """计算综合风险评分 0.0-1.0"""
        if not self.smells:
            return 0.0

        weights = {"critical": 1.0, "high": 0.7, "medium": 0.4, "low": 0.1}
        total_weight = sum(weights.get(s.severity, 0) for s in self.smells)
        normalized = min(1.0, total_weight / 10)  # 10 个 high 级别达到满分
        return round(normalized, 2)
