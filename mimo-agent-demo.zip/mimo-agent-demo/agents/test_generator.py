"""
TestGenerator Agent: 为变更代码自动生成单元测试
确保新代码路径 100% 覆盖
"""
import ast
import re
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from enum import Enum

class TestType(Enum):
    UNIT = "unit"
    INTEGRATION = "integration"
    EDGE_CASE = "edge_case"
    REGRESSION = "regression"

@dataclass
class TestCase:
    name: str
    test_type: TestType
    target_function: str
    input_data: str
    expected_output: str
    assertions: List[str]
    coverage_target: str  # line, branch, path

class TestGenerator:
    """
    测试生成 Agent

    核心能力：
    1. 变更感知：仅针对被修改的代码生成测试
    2. 分支覆盖：分析条件分支，确保每个分支都有测试
    3. 边界值：自动识别边界条件（None, 空列表, 极大值等）
    4. Mock 生成：自动识别外部依赖并生成 Mock
    """

    def __init__(self, llm_client: Optional[Any] = None):
        self.llm = llm_client
        self.test_cases: List[TestCase] = []

    async def execute(self, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """
        执行测试生成

        Args:
            inputs: 包含重构计划和原始代码

        Returns:
            生成的测试用例列表和 pytest 代码
        """
        plan = inputs.get("pr_reason", {}).get("plan", [])
        raw_files = inputs.get("raw_input", {}).get("pr_data", {}).get("diff_files", [])

        self.test_cases = []
        test_files = {}

        for file_info in raw_files:
            path = file_info.get("path", "")
            content = file_info.get("content", "")

            if not content or not path.endswith(".py"):
                continue

            # 解析 AST 找到被修改的函数
            try:
                tree = ast.parse(content)
            except SyntaxError:
                continue

            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    # 检查该函数是否在重构计划中
                    if self._is_target_function(node, plan):
                        cases = self._generate_for_function(node, content, path)
                        self.test_cases.extend(cases)

        # 生成 pytest 代码
        pytest_code = self._generate_pytest_code()

        return {
            "tests_count": len(self.test_cases),
            "test_cases": [self._case_to_dict(c) for c in self.test_cases],
            "pytest_code": pytest_code,
            "coverage_estimate": self._estimate_coverage(),
            "missing_branches": self._find_uncovered_branches()
        }

    def _is_target_function(self, node: ast.FunctionDef, plan: List[Dict]) -> bool:
        """检查函数是否是重构目标"""
        for item in plan:
            target = item.get("target", "")
            if node.name in target or str(node.lineno) in target:
                return True
        return False

    def _generate_for_function(self, node: ast.FunctionDef, content: str, 
                               file_path: str) -> List[TestCase]:
        """为单个函数生成测试用例"""
        cases = []

        # 1. 基础功能测试
        cases.append(TestCase(
            name=f"test_{node.name}_basic_functionality",
            test_type=TestType.UNIT,
            target_function=node.name,
            input_data=self._infer_input_signature(node),
            expected_output="expected_result",
            assertions=["assert result == expected", "assert result is not None"],
            coverage_target="line"
        ))

        # 2. 分析分支结构，为每个分支生成测试
        branches = self._extract_branches(node)
        for i, branch in enumerate(branches):
            cases.append(TestCase(
                name=f"test_{node.name}_branch_{i}_{branch['condition']}",
                test_type=TestType.UNIT,
                target_function=node.name,
                input_data=branch["input"],
                expected_output=branch["expected"],
                assertions=[f"assert result == {branch['expected']}"],
                coverage_target="branch"
            ))

        # 3. 边界值测试
        edge_cases = self._infer_edge_cases(node)
        for edge in edge_cases:
            cases.append(TestCase(
                name=f"test_{node.name}_edge_{edge['name']}",
                test_type=TestType.EDGE_CASE,
                target_function=node.name,
                input_data=edge["input"],
                expected_output=edge.get("expected", "None"),
                assertions=[edge.get("assertion", "assert result is not None")],
                coverage_target="path"
            ))

        # 4. 异常测试
        if self._has_exception_handling(node):
            cases.append(TestCase(
                name=f"test_{node.name}_raises_exception",
                test_type=TestType.REGRESSION,
                target_function=node.name,
                input_data="invalid_input",
                expected_output="Exception",
                assertions=["with pytest.raises(Exception):", "    function_call(invalid_input)"],
                coverage_target="path"
            ))

        return cases

    def _extract_branches(self, node: ast.FunctionDef) -> List[Dict]:
        """提取函数内的条件分支"""
        branches = []

        for child in ast.walk(node):
            if isinstance(child, ast.If):
                # 提取条件表达式
                condition = ast.unparse(child.test) if hasattr(ast, 'unparse') else "condition"

                # 为 True 分支生成输入
                branches.append({
                    "condition": condition,
                    "input": f"{{'trigger': '{condition}_true'}}",
                    "expected": "true_branch_result"
                })

                # 如果有 else，为 False 分支生成
                if child.orelse:
                    branches.append({
                        "condition": f"not ({condition})",
                        "input": f"{{'trigger': '{condition}_false'}}",
                        "expected": "false_branch_result"
                    })

        return branches

    def _infer_input_signature(self, node: ast.FunctionDef) -> str:
        """推断函数的输入签名"""
        args = []
        for arg in node.args.args:
            # 尝试从类型注解推断
            if arg.annotation:
                if hasattr(ast, 'unparse'):
                    type_hint = ast.unparse(arg.annotation)
                else:
                    type_hint = "Any"
            else:
                type_hint = "Any"
            args.append(f"{arg.arg}: {type_hint}")

        return f"({', '.join(args)})"

    def _infer_edge_cases(self, node: ast.FunctionDef) -> List[Dict]:
        """推断边界条件"""
        edge_cases = []

        # 检查参数类型注解
        for arg in node.args.args:
            if arg.annotation:
                type_name = ast.unparse(arg.annotation) if hasattr(ast, 'unparse') else ""

                if "list" in type_name.lower() or "List" in type_name:
                    edge_cases.extend([
                        {"name": "empty_list", "input": "[]", "assertion": "assert result == [] or result is not None"},
                        {"name": "single_element", "input": "[1]", "assertion": "assert len(result) >= 0"}
                    ])
                elif "str" in type_name.lower() or "str" in type_name:
                    edge_cases.extend([
                        {"name": "empty_string", "input": "''", "assertion": "assert isinstance(result, str)"},
                        {"name": "unicode", "input": "'测试中文'", "assertion": "assert result is not None"}
                    ])
                elif "int" in type_name.lower():
                    edge_cases.extend([
                        {"name": "zero", "input": "0", "assertion": "assert result is not None"},
                        {"name": "negative", "input": "-1", "assertion": "assert result is not None"}
                    ])

        # 通用边界
        edge_cases.append({
            "name": "none_input",
            "input": "None",
            "assertion": "assert result is None or result is not None"
        })

        return edge_cases

    def _has_exception_handling(self, node: ast.FunctionDef) -> bool:
        """检查函数是否包含异常处理"""
        for child in ast.walk(node):
            if isinstance(child, (ast.Try, ast.Raise)):
                return True
        return False

    def _generate_pytest_code(self) -> str:
        """生成完整的 pytest 测试文件代码"""
        code_lines = [
            "import pytest",
            "from unittest.mock import Mock, patch",
            "",
            "# Auto-generated by TestGenerator Agent",
            "# Coverage target: line + branch",
            "",
        ]

        for case in self.test_cases:
            code_lines.append(f"def {case.name}():")
            code_lines.append(f'    """{case.test_type.value} test for {case.target_function}"""')
            code_lines.append(f"    # Arrange")
            code_lines.append(f"    input_data = {case.input_data}")
            code_lines.append(f"    ")
            code_lines.append(f"    # Act")
            code_lines.append(f"    result = {case.target_function}(**input_data) if isinstance(input_data, dict) else {case.target_function}(input_data)")
            code_lines.append(f"    ")
            code_lines.append(f"    # Assert")
            for assertion in case.assertions:
                code_lines.append(f"    {assertion}")
            code_lines.append("")

        return "\n".join(code_lines)

    def _estimate_coverage(self) -> Dict[str, float]:
        """估算覆盖率"""
        if not self.test_cases:
            return {"line": 0.0, "branch": 0.0}

        line_tests = len([c for c in self.test_cases if c.coverage_target == "line"])
        branch_tests = len([c for c in self.test_cases if c.coverage_target == "branch"])

        return {
            "line": min(1.0, line_tests * 0.3),  # 粗略估算
            "branch": min(1.0, branch_tests * 0.2)
        }

    def _find_uncovered_branches(self) -> List[str]:
        """识别未被覆盖的分支"""
        # 简化版：返回需要额外关注的分支
        uncovered = []
        for case in self.test_cases:
            if case.test_type == TestType.EDGE_CASE:
                uncovered.append(f"Edge case: {case.name}")
        return uncovered

    def _case_to_dict(self, case: TestCase) -> Dict[str, Any]:
        return {
            "name": case.name,
            "type": case.test_type.value,
            "target": case.target_function,
            "input": case.input_data,
            "expected": case.expected_output,
            "assertions": case.assertions,
            "coverage": case.coverage_target
        }
